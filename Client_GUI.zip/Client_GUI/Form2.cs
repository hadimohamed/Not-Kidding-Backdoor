﻿using System;
using System.Windows.Forms;
 
namespace Client_GUI
{
    public partial class Form2 : Form
    {
      
        public Form2()
        {
            InitializeComponent();
        }


        

        private void Form2_Load_1(object sender, EventArgs e)
        {
           
            
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

            



        }
    }

    }

