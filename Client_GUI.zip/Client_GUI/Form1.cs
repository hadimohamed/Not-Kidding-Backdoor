﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Threading;
namespace Client_GUI
{
    public partial class Form1 : Form
    {
        static Socket sck, acc;
        static int port = 9000;
        static IPAddress ip;
        static Thread rec;
        public string msg;
        public Form2 frm2 = new Form2();
        public Form1()
        {
            InitializeComponent();
        }


        public void recv()
        {
            while (true)
            {
                nn:
                try
                {
                    Thread.Sleep(500);
                    byte[] buffer = new byte[1500];
                    int rec = sck.Receive(buffer, 0, buffer.Length, 0);
                    Array.Resize(ref buffer, rec);
                    msg = Encoding.Default.GetString(buffer);
                }
                catch { goto nn; }
                if (msg == "1") { frm2.Show(); byte[] conmsg = Encoding.Default.GetBytes("BLUE Screen ON"); sck.Send(conmsg, 0, conmsg.Length, 0); }
                if (msg == "2") { frm2.Hide(); byte[] conmsg = Encoding.Default.GetBytes("BLUE SCREEN DOWN"); sck.Send(conmsg, 0, conmsg.Length, 0); }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            byte[] conmsg = Encoding.Default.GetBytes("CLIENT CLOSED THE SESSION "); sck.Send(conmsg, 0, conmsg.Length, 0);
            sck.Close();
            this.Close();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Show();
            ll:
            rec = new Thread(recv);
            ip = IPAddress.Parse("127.0.0.1");
            sck = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
          
            try
            {
                sck.Connect(new IPEndPoint(ip, 9000));
                rec.Start();
                byte[] conmsg = Encoding.Default.GetBytes("Client Connected \n Send 1 To Show Screen And 2 To Hide It");
                sck.Send(conmsg, 0, conmsg.Length, 0);
            }
            catch { goto ll; }
             



        }
    }
}
